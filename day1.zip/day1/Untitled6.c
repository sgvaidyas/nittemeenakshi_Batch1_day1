
 
 #include<stdio.h>
 
 void main()
 {
 	int n,i,j;
 	printf("No of terms = ");
 	scanf("%d",&n);
 	for(i=1,j=n; i<=n ; i++,j--)
 		printf("%d\n",i*j);
 }
 
 
 
 
 
 
 
 
 
 
