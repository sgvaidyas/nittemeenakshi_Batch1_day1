/*
n=7
cnt=1
while(cnt<=n)
cnt = i=1  print(i)
 1     1      1       i=i+3 = 1+3 =4   cnt++
 2     4      4               4+3=7    3
 3     7      7               7+3=10   4
 4     10    10                   13   5
 5     13    13                   16   6
 6     16    16                   19   7
 7     19    19                   22   8
 */
 
 
 
 
 
 #include<stdio.h>
 
 void main()
 {
 	int n,i=1,cnt=1;
 	printf("No of terms = ");
 	scanf("%d",&n);
 	while(cnt<=n)
 	{
 		printf("%d\n",i);
 		i+=3;
 		cnt++;
	 }
 }
 
 
 
 
 
 
 
 
 
 
