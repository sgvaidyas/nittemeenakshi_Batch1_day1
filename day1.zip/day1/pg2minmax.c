#include<stdio.h>
void main()
{
	int a, b, c, sum;
	printf("Enter the values of a=");
	scanf("%d",&a);
	printf("Enter the values of b=");
	scanf("%d",&b);
	printf("Enter the values of c=");
	scanf("%d",&c);
	if(a>b)
	{
		if(a>c)
		{
			printf("a is greater=%d",a);
		}
		else
		{
			printf("c is greater=%d",c);
		}
	}
	else
	{
		if(b>c)
		{
			printf("b is greater=%d",b);
		}
		else
		{
			printf("c is greater=%d",c);
		}
		sum= a+b+c;
		printf("Sum=%d",sum);
	}	
}
