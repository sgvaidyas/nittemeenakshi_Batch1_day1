#include<stdio.h>
void main()
{
	int a, b, i;
	printf("Enter a and b=");
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		for(i=b;i<a;i++)
			printf("%d\t",i);
	}
	else
	{
		for(i=a;i<b;i++)
			printf("%d\t",i);
	}
}
