#include<stdio.h>
void main()
{
	int a, b, i, low, high;
	printf("Enter a and b=");
	scanf("%d%d",&a,&b);
	low= (a<b)?a:b;
	high = (a>b)?a:b;
	for(i=low;i<high;i++)
		printf("%d\t",i);
}
