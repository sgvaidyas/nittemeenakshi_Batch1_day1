#include<stdio.h>
void main()
{
	int ch, quantity, price, total=0, flag;
	do
	{
		printf("1 IDLI (40)\n");
		printf("2 DOSA (50)\n");
		printf("3 POORI (45)\n");
		printf("4 TEA  (10)\n");
		printf("Enter the choice = ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("Enter the quantity=");
					scanf("%d",&quantity);
					price=quantity*40;
					break;
			case 2:printf("Enter the quantity=");
					scanf("%d",&quantity);
					price=quantity*50;
					break;
			case 3:printf("Enter the quantity=");
					scanf("%d",&quantity);
					price=quantity*45;
					break;
			case 4:printf("Enter the quantity=");
					scanf("%d",&quantity);
					price=quantity*10;
					break;
			default:printf("Invalid choice");	
		}
		total=total+price;
		printf("Press 1 to continue\n");
		scanf("%d",&flag);
	}while(flag==1);
  	printf("Please pay the bill=%d",total);
}
